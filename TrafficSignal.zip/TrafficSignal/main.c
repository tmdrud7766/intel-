#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include "ap/TrafficSignal/TrafficSignal.h"


//       헤더파일에 
//#define      trafficButtonDDR   DDRA
//#define      trafficButtonPIN   PINA
//#define      trafficLedDDR      DDRE
//#define      trafficLedPORT      PORTE
//#define      B_AUTO            0
//#define      B_MANUAL         1
//#define      B_SWITCHING         2

//enum {AUTO, MANUAL};     c파일에 ㄱㄱ
//enum {RED_GREEN, RED_YELLOW, GREEN_RED, YELLOW_RED};
	
// 헤더파일
//void TrafficSignal_Auto();
//void TrafficSignal_Manual();
//void TrafficSignal_RedGreen();
//void TrafficSignal_RedYellow();
//void TrafficSignal_GreenRed();
//void TrafficSignal_YellowRed();


int main(void)
{
	
	TrafficSignal_init();
	//trafficButtonDDR &= ~((1<<B_AUTO) | (1<<B_MANUAL) | (1<<B_SWITCHING));
	//trafficLedDDR |= ((1<<0) | (1<<1) | (1<<2) | (1<<3) | (1<<4) |(1<<5));
	//
	//uint8_t trafficModeState = AUTO;
	//trafficState = RED_GREEN;
	
	while (1)
	{	
		
		
		
		
		trafficSignal_execute();
		// Mode Event Check
		
		
		//if((trafficButtonPIN & (1<<B_AUTO)) == 0)
		//{
			//trafficModeState = AUTO;
		//}
		//else if((trafficButtonPIN & (1<<B_MANUAL)) == 0)
		//{
			//trafficModeState = MANUAL;
		//}
		//
		//// Mode Running
		//switch(trafficModeState)
		//{
			//case AUTO :
			//TrafficSignal_Auto();
			//break;
			//case MANUAL :
			//TrafficSignal_Manual();
			//break;
		//}
		
	}
}


//void TrafficSignal_Manual()   c파일
//{
	//switch (trafficState)
	//{
		//case RED_GREEN :
		//TrafficSignal_RedGreen();
		//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
		//{
			//trafficState = RED_YELLOW;
		//}
		//break;
		//case RED_YELLOW :
		//TrafficSignal_RedYellow();
		//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
		//{
			//trafficState = GREEN_RED;
		//}
		//break;
		//case GREEN_RED :
		//TrafficSignal_GreenRed();
		//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
		//{
			//trafficState = YELLOW_RED;
		//}
		//break;
		//case YELLOW_RED :
		//TrafficSignal_YellowRed();
		//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
		//{
			//trafficState = RED_GREEN;
		//}
		//break;
	//}
//}

//void TrafficSignal_Auto()
//{
	//switch (trafficState)
	//{
		//case RED_GREEN :
		//TrafficSignal_RedGreen();
		//_delay_ms(3000);
		//trafficState = RED_YELLOW;
		//break;
		//case RED_YELLOW :
		//TrafficSignal_RedYellow();
		//_delay_ms(1000);
		//trafficState = GREEN_RED;
		//break;
		//case GREEN_RED :
		//TrafficSignal_GreenRed();
		//_delay_ms(3000);
		//trafficState = YELLOW_RED;
		//break;
		//case YELLOW_RED :
		//TrafficSignal_YellowRed();
		//_delay_ms(1000);
		//trafficState = RED_GREEN;
		//break;
	//}
//}    c파일


//void TrafficSignal_RedGreen()     c언어파일 
//{
	//trafficLedPORT = ((1<<0) | (1<<4));
//}
//
//void TrafficSignal_RedYellow()
//{
	//trafficLedPORT = ((1<<0) | (1<<5));
//}
//
//void TrafficSignal_GreenRed()
//{
	//trafficLedPORT = ((1<<2) | (1<<6));
//}
//
//void TrafficSignal_YellowRed()
//{
	//trafficLedPORT = ((1<<1) | (1<<6));
//}