﻿#include "TrafficSignal.h"

button_t button_auto,button_manual,button_switch;


uint8_t trafficModeState;
uint8_t trafficState;


enum {AUTO, MANUAL};  //h ,c 노상관
enum {RED_GREEN, RED_YELLOW, GREEN_RED, YELLOW_RED};  //h ,c 노상관
	
	
	void TrafficSignal_RedGreen()
	{
		trafficLedPORT = ((1<<0) | (1<<4));
	}

	void TrafficSignal_RedYellow()
	{
		trafficLedPORT = ((1<<0) | (1<<5));
	}

	void TrafficSignal_GreenRed()
	{
		trafficLedPORT = ((1<<2) | (1<<6));
	}

	void TrafficSignal_YellowRed()
	{
		trafficLedPORT = ((1<<1) | (1<<6));
	}
	
	
	
	void TrafficSignal_Manual()
	{
		switch (trafficState)
		{
			case RED_GREEN :
			TrafficSignal_RedGreen();
			if((trafficButtonPIN & (1<<B_SWITCHING))==0)
			{
				trafficState = RED_YELLOW;
			}
			break;
			case RED_YELLOW :
			TrafficSignal_RedYellow();
			if((trafficButtonPIN & (1<<B_SWITCHING))==0)
			{
				trafficState = GREEN_RED;
			}
			break;
			case GREEN_RED :
			TrafficSignal_GreenRed();
			if((trafficButtonPIN & (1<<B_SWITCHING))==0)
			{
				trafficState = YELLOW_RED;
			}
			break;
			case YELLOW_RED :
			TrafficSignal_YellowRed();
			if((trafficButtonPIN & (1<<B_SWITCHING))==0)
			{
				trafficState = RED_GREEN;
			}
			break;
		}
	}
	
	void TrafficSignal_Auto()
	{
		switch (trafficState)
		{
			case RED_GREEN :
			TrafficSignal_RedGreen();
			_delay_ms(3000);
			trafficState = RED_YELLOW;
			break;
			case RED_YELLOW :
			TrafficSignal_RedYellow();
			_delay_ms(1000);
			trafficState = GREEN_RED;
			break;
			case GREEN_RED :
			TrafficSignal_GreenRed();
			_delay_ms(3000);
			trafficState = YELLOW_RED;
			break;
			case YELLOW_RED :
			TrafficSignal_YellowRed();
			_delay_ms(1000);
			trafficState = RED_GREEN;
			break;
		}
	}
	
	

void TrafficSignal_init(){
	
	
    Led_init();
	Button_init(&button_auto,&DDRA,&PINA,0);
	Button_init(&button_manual,&DDRA,&PINA,1);
	Button_init(&button_switch,&DDRA,&PINA,2);
	
	trafficModeState = AUTO;
	trafficState = RED_GREEN;
}


void trafficSignal_execute(){
	
	
	if((trafficButtonPIN & (1<<B_AUTO)) == 0)
	{
		trafficModeState = AUTO;
	}
	else if((trafficButtonPIN & (1<<B_MANUAL)) == 0)
	{
		trafficModeState = MANUAL;
	}
	
	// Mode Running
	switch(trafficModeState)
	{
		case AUTO :
		TrafficSignal_Auto();
		break;
		case MANUAL :
		TrafficSignal_Manual();
		break;
	}
	
	
	
}