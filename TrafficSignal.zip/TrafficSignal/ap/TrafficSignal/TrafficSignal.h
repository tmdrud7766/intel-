﻿/*
 * TrafficSignal.h
 *
 * Created: 2024-11-26 오후 1:51:22
 *  Author: iot
 */ 


#include "../../diver/BUTTON/Button.h"   //헤더끼리 연결
#include "../../diver/LED/LED.h"   //헤더끼리 연결


#ifndef TRAFFICSIGNAL_H_
#define TRAFFICSIGNAL_H_


#define F_CPU 16000000UL
#include <util/delay.h>
#include <avr/io.h>


#define      trafficButtonDDR   DDRA
#define      trafficButtonPIN   PINA
#define      trafficLedDDR      DDRE
#define      trafficLedPORT      PORTE
#define      B_AUTO            0
#define      B_MANUAL         1
#define      B_SWITCHING         2




void TrafficSignal_Auto();
void TrafficSignal_Manual();
void TrafficSignal_RedGreen();
void TrafficSignal_RedYellow();
void TrafficSignal_GreenRed();
void TrafficSignal_YellowRed();
void TrafficSignal_init();
void trafficSignal_execute();

#endif /* TRAFFICSIGNAL_H_ */