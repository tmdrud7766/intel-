﻿/*
 * IncFile1.h
 *
 * Created: 2024-11-26 오후 1:12:05
 *  Author: iot
 */ 


#ifndef LEDMACHINE_H_
#define LEDMACHINE_H_
#define  LED_DDR DDRE
#define  LED_PORT PORTE


#define F_CPU 16000000UL
#include <util/delay.h>
#include <avr/io.h>


void Led_init();
void Led_writeData(uint8_t data);
void Led_allOff();
void Led_allOn();


#endif /* LEDMACHINE_H_ */