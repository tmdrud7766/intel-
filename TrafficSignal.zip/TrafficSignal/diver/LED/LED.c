﻿/*
 * CFile1.c
 *
 * Created: 2024-11-26 오후 1:11:52
 *  Author: iot
 */ 
#include "LED.h"




void Led_init(){
	
	LED_DDR = 0xff;
}

void Led_writeData(uint8_t data)
{
	LED_PORT = data;
	
}


void Led_allOff(){
	
	LED_PORT = 0x00;
	
}

void Led_allOn(){
	
	LED_PORT = 0xff;
	
}