﻿/*
 * TimeTick.h
 *
 * Created: 2024-12-03 오후 3:38:41
 *  Author: iot
 */ 


#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>


void incTick();

void clearTick();

uint32_t getTick();