﻿/*
 * TimeTick.c
 *
 * Created: 2024-12-03 오후 3:38:36
 *  Author: iot
 */ 
#include "TimeTick.h"


uint32_t  timeTick = 0;

void incTick()
{
	timeTick++;
}

void clearTick(){
	
	timeTick = 0;
	
}

uint32_t getTick(){
	
	return timeTick;
}