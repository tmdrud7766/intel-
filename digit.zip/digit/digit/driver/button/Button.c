﻿#include "Button.h"

void Button_init(button_t *btn, volatile uint8_t *ddr, volatile uint8_t *pin, uint8_t pinNum)
{
	btn ->DDR = ddr;  //버튼의 입출력 설정
	btn ->PIN = pin;   //버튼이 연결된 포트의 pin레지스터 설정
	btn ->pinNum = pinNum;  // 버튼 핀번호 설정
	btn ->prevState = RELEASED;  //버튼이전상태를 설정
	//*btn ->DDR &= ~(1<<btn->pinNum); 1개핀만 0으로
	Gpio_initPin(btn -> DDR, btn -> pinNum,INPUT);
}

uint8_t Button_GetState(button_t *btn)
{	
	//uint8_t curState = (*btn->PIN & (1<<btn->pinNum) );        //오른쪽부
	uint8_t curState = Gpio_readPin(btn ->PIN,btn ->pinNum);
	
	
	if((curState == PUSHED) && (btn->prevState ==RELEASED))
	{
		_delay_ms(10);
		btn->prevState = PUSHED;
		return ACT_PUSHED;
	}
	else if ((curState != PUSHED) && (btn->prevState ==PUSHED))
	{
		_delay_ms(10);
		btn->prevState = RELEASED;
		return ACT_RELEASED;
	}
	return ACT_NONE;
}