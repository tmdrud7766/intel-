/*
* digit.c
*
* Created: 2024-12-03 오전 9:20:01
* Author : iot
*/
#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>     //인터럽트 사용헤더파일 추가
#include "driver/FND/FND.h"    //h에 연결
#include "driver/button/Button.h"
#include "periph/TIM/TIM.h"
#include "common/TimeTick/TimeTick.h"

enum {Run,Stop,Reset};


ISR(TIMER0_OVF_vect)   //어떤조건에 대한 isr인지 알려 주야함   이함수는 여러개 가능   interrupt 발생시 이 함수 호출  1ms
{
	
	FND_ISR_Process();
	TCNT0 = 130;
	incTick();
	
}



int main(void)
{


	FND_init();
	TIMER0_OVF_init();


	DDRD = 0xff;
	
	// Timer/counter0 overflow Interrupt
	//prescaler 1/1024
	//CS0  CS01 CS00
	//   1   1    1
	TCCR0 |= (1<<CS02) | (0<<CS01) | (1<<CS00);
	// TIMSK    Timer Overflow Interrpt Enable  0번째 비트를 켜줌
	TIMSK  |= (1<< TOIE0);  //인터럽트 발생전  설정만해줌
	//Global Interrput Enable
	sei();   //sei 다음에 인터럽트 발생


	uint16_t counter  = 3215;
	uint8_t upCounterState = Stop;

	button_t btnRunStop,btnReset;

	Button_init(&btnRunStop,&DDRA,&PINA,0);
	Button_init(&btnReset,&DDRA,&PINA,1);
	
	
	uint32_t prevTime = 0;

	while (1)
	{
		
		switch(upCounterState)
		{
			case Stop :
			if (Button_GetState(&btnRunStop) == ACT_RELEASED)
			{
				upCounterState = Run;
			}else if (Button_GetState(&btnReset) == ACT_RELEASED)
			{
				upCounterState = Reset;
				
			}
			FND_setfndData(counter);
			break;
			
			case Run:
			
			if (Button_GetState(&btnRunStop) == ACT_RELEASED)
			{
				upCounterState = Stop;
			}
			FND_setfndData(counter);
			break;
			
			case Reset:
			if(Button_GetState(&btnRunStop) == ACT_RELEASED)
			{
				upCounterState = Stop;  //???? 맞나?
			}

			
			break;
			
			
			
		}
		
		
		switch(upCounterState)
		{
			case Stop :
			FND_setfndData(counter);
			
			break;
			
			case Run:
			
			if (getTick() - prevTime >=  1000)
			{
				prevTime = getTick();
				FND_setfndData(counter++);
			}
			
			
			break;
			
			
			
			case Reset :
			counter = 0;
			break;
			
		}
	
		
	}
}



