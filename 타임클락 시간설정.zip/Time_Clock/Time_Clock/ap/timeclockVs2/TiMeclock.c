﻿/*
* TiMeclock.c
*
* Created: 2024-12-04 오후 2:33:06
*  Author: iot
*/
#include "TiMeclock.h"   //같은폴더니까

uint16_t milisec;
uint8_t sec,min,hour;
button_t btnChangeMode , btnModify ,btnIncHour,btnIncMin;
uint16_t ClockState;

void TimeClock_init(){
	

	
	milisec = 0;
	sec = 0;
	min = 0;
	hour = 0;
	
	
	FND_init();
	TIM_OVF_init();
	TIM_CTC_init();
	
	
	Button_init(&btnChangeMode,&DDRA,&PINA,0);
	Button_init(&btnModify,&DDRA,&PINA,1);
	Button_init(&btnIncHour,&DDRA,&PINA,2);
	Button_init(&btnIncMin,&DDRA,&PINA,3);
	
	ClockState = SEC_MILISEC;
	
}


void Clock_incMilisec(){   //리턴은 안내려가고 값을 반환
	


	milisec = (milisec + 1) %1000;
	
	if(milisec < 500) FND_colonOn();
	else FND_colonOff();
	
	if(milisec) return;    // 0 값이 되면 거짓이라 다음 스텝으로 ㄱㄱ
	
	sec = ( sec+1 ) % 60;
	
	if(sec) return;
	
	min = ( min +1) % 60;
	if(min) return;
	
	hour = (hour + 1) % 24;
	
	
}
void Clock_Run(){  //메인문 실행
	
	buttonEvent();
	TimeClock_execute();

}




void buttonEvent(){    //버튼액션
	

	switch(ClockState){
		
		case HOUR_MIN :
		if(Button_GetState(&btnChangeMode) == RELEASED){    //1
			ClockState = SEC_MILISEC;
		}
		if(Button_GetState(&btnModify) == RELEASED){    //1
			ClockState = HOUR_MIN;
		}
		if(Button_GetState(&btnIncHour) == RELEASED){
			hour = (hour+1)%24  ;
		}
		if(Button_GetState(&btnIncMin) == RELEASED){		
			min = (min)%60+1;
					
		}
		

		
		case HOUR_INC : 
		
		if(Button_GetState(&btnIncHour) == RELEASED){
			
		hour = (hour+1)%24  ;
		}
		
		break;
		
		case MODIFY :
		if(Button_GetState(&btnModify) == RELEASED){    //1
			ClockState = HOUR_MIN;
		}
		
		break;
		
		
		case SEC_MILISEC:
		if(Button_GetState(&btnChangeMode) == RELEASED){ 
			  
			ClockState = HOUR_MIN;
			
		}
		break;
		
		case MIN_INC :
		if(Button_GetState(&btnIncMin) == RELEASED){
			
			min = (min+1)%60;
				
		}
		
		
		break;
		
		
	
		
	}
}



void TimeClock_execute(){   //디스플레이 찍어주기

	uint16_t hourMinDisplay = (hour * 100) + (min);
	uint16_t secMilsecDisplay = (sec *100) + (milisec/10);

	switch(ClockState){

		case SEC_MILISEC :

		FND_setfndData(secMilsecDisplay);
		

		break;






		case HOUR_MIN:
		
		FND_setfndData(hourMinDisplay);
		
		break;
		
		
		


	}

}