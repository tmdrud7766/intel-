﻿/*
* TiMeclock.h
*
* Created: 2024-12-04 오후 2:33:13
*  Author: iot
*/

#define F_CPU 16000000UL
#include <util/delay.h>
#include <avr/io.h>
#include "../../driver/FND/FND.h"
#include "../../periph/TIM/TIM.h"
#include "../../driver/Button/Button.h"



enum{SEC_MILISEC ,HOUR_MIN,MODIFY,HOUR_INC ,MIN_INC };



void TimeClock_init();
void Clock_incMilisec();
void Clock_Run();
void buttonEvent();
void TimeClock_execute();