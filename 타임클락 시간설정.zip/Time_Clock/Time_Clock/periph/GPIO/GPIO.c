﻿#include "GPIO.h"   //헤더 연결

void Gpio_initPort(volatile uint8_t *DDR, uint8_t dir){    // 전체를 입출력으로  설정 
	if(dir == OUTPUT){
		*DDR = 0xff;
	}else{
		*DDR = 0x00;
	}
}
void Gpio_initPin(volatile uint8_t *DDR,uint8_t pinNum, uint8_t dir){    //해당 핀을 입력 모드로 설정하는 함수입니다. 이 함수는 버튼 핀을 입력으로 설정하는 데 사용됩니다.
	if(dir == OUTPUT){
		*DDR |= (1 << pinNum);
	}else{
		*DDR &= ~(1 << pinNum);
	}
}
//Output - port
void Gpio_writePort(volatile uint8_t *PORT, uint8_t data){
	*PORT = data;   //포트번호 설정  8비트까지 
}
//Output - pin
void Gpio_writePin(volatile uint8_t *PORT, uint8_t pinNum, uint8_t state){    //읽은 포트의 상태 ,넘버 ,1 을출력하는지 0을 출력하는지
	if(state == GPIO_SET){
		*PORT |= (1<<pinNum); //1일때
	}else{
		*PORT &= ~(1<<pinNum); // 0일때
	}
}
//Input - port
uint8_t Gpio_readPort(volatile uint8_t *PIN){ //입력받은 핀의 포트  uint8_t portBState = Gpio_readPort(&PINB);
	return *PIN;
}
//Input - pin
uint8_t Gpio_readPin(volatile uint8_t *PIN, uint8_t pinNum){  //Gpio_readPin 함수는 특정 핀의 상태를 읽고, **High (1)**이면 1을, **Low (0)**이면 0을 반환합니다.*PIN & (1 << pinNum) 비트 연산을 통해 지정한 핀의 상태를 추출하고, 그 값을 != 0 조건을 통해 High와 Low를 구분합니다.
	return ((*PIN & (1 << pinNum))!=0);
	//(xxxx xxx0 & 0000 000) != 0  눌렀을때 0 반환 
}