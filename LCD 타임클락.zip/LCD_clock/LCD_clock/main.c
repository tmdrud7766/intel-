/*
 * LCD_clock.c
 *
 * Created: 2024-12-05 오후 2:35:06
 * Author : iot
 */ 
#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "driver/LCD/LCD.h"
#include "ap/LCD_TIMECLOCK/LCDtime.h"
#include "driver/FND/FND.h"


ISR(TIMER0_OVF_vect)   //어떤조건에 대한 ISR인지 알려 주야함   이함수는 여러개 가능   interrupt 발생시 이 함수 호출  1ms
{
	
	FND_ISR_Process();
	TCNT0 = 130;
	
}

ISR(TIMER2_COMP_vect ){   //타이머값오버  플로우로 설정
	
	
	Clock_incMilisec();
	
	
}




int main(void)
{
	TimeClock_init();
	
	
	sei();
	
	while (1)
	{
		Clock_Run();
	}
}

