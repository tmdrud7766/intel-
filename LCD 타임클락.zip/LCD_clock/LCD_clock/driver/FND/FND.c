﻿/*
 * FND.c
 *
 * Created: 2024-12-03 오후 1:08:48
 *  Author: iot
 */ 
#include "FND.h"



uint16_t  FNDstate  =  0;
uint16_t fndData = 0;
uint8_t fndColonFlag;

void FND_init() 
{
	
	FND_DIGIT_DDR = 0xff;
	FND_NUM_DDR = 0xff;
	
	
}




void FND_dispNum(uint16_t fndNum)   //임의의 숫자 
{
	uint8_t	fndFont[11]= {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x67 ,0x80};
	
	
	static uint8_t fndDigiState = 0;   //fnd 자릿수 상태
	fndDigiState = ( fndDigiState + 1 ) % 5 ; //자릿수가 4개라 0 1 2 3
	
	FND_DIGIT_PORT |= (1<<7) | (1<<6) | (1<<5) | (1<<4);     //4,5,6,7 high 출력해서 다꺼줌  캐소드 방식 
	
	switch(fndDigiState){
		
		
		case 0 :
		
		FND_NUM_PORT = fndFont [fndNum/1000%10];   //천의 자리 선택
		FND_DIGIT_PORT &= ~(1<<FND_DIGIT0);        //자릿수 선택
		break;
		
		case 1 :

		FND_NUM_PORT = fndFont [fndNum/100%10];   //백의 자리
		FND_DIGIT_PORT &= ~(1<<FND_DIGIT1);

		break;
		
		case 2 :

		FND_NUM_PORT = fndFont [fndNum/10%10]; //십의자리
		FND_DIGIT_PORT &= ~(1<<FND_DIGIT2);

		break;
		
		case 3 :
		

		FND_NUM_PORT = fndFont [fndNum%10];  //
		FND_DIGIT_PORT &= ~(1<<FND_DIGIT3);    //1의 자리 선택

		
		break;
		
		
		case 4 : 
		
			if(fndColonFlag)FND_DIGIT_PORT = fndFont[FND_COLON];
			else FND_NUM_PORT = 0x00;
			FND_NUM_PORT = fndFont [10];   // DP
			FND_DIGIT_PORT &= ~(1<<FND_DIGIT1);       //백의자리 
		
		break;
		
			
	}
	
	
}


void FND_setfndData(uint16_t data)
{
	
	
	fndData = data;
	
}


void FND_ISR_Process()
{
	
	
	FND_dispNum(fndData);
	
}


void FND_colonOn(){
	
	fndColonFlag = 1;
	
}



void FND_colonOff(){
	
	fndColonFlag = 0;
	
}