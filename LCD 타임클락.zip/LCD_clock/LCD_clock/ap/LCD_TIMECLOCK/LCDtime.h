﻿/*
 * LCDtime.h
 *
 * Created: 2024-12-05 오후 2:42:59
 *  Author: iot
 */ 


#define F_CPU 16000000UL
#include <util/delay.h>
#include <avr/io.h>
#include "../../driver/FND/FND.h"
#include "../../periph/TIM/TIM.h"
#include "../../driver/Button/Button.h"
#include "../../driver/LCD/LCD.h"

enum{SEC_MILISEC ,HOUR_MIN,MODIFY,HOUR_INC ,MIN_INC };
	
	
void FND_colonOff();
void FND_colonOn();
void TimeClock_init();
void Clock_incMilisec();
void Clock_Run();
void buttonEvent();
void TimeClock_execute();
void TIM_OVF_init();	
void LCD_execute();
void LCD_writeStringXY(uint8_t row, uint8_t col, char *str);
	
	
	
	
	
	
	